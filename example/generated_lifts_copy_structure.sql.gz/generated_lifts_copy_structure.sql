# ************************************************************
# Sequel Pro SQL dump
# Version 3408
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 127.0.0.1 (MySQL 5.5.19)
# Database: test
# Generation Time: 2012-07-06 14:54:34 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table generated_lifts_copy
# ------------------------------------------------------------

CREATE TABLE `generated_lifts_copy` (
  `hash_id` varchar(40) NOT NULL,
  `lift` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `sequence` tinyint(3) unsigned NOT NULL,
  `type` enum('s','b') NOT NULL,
  `date` date NOT NULL,
  `time` time DEFAULT NULL,
  `departure_id` smallint(5) unsigned NOT NULL,
  `departure_district_id` int(10) unsigned DEFAULT NULL,
  `destination_id` smallint(5) unsigned NOT NULL,
  `destination_district_id` int(10) unsigned DEFAULT NULL,
  `event_id` tinyint(1) DEFAULT NULL,
  `fanride_id` int(10) NOT NULL,
  `driver_is_smoker` tinyint(1) NOT NULL,
  `seats` enum('1','2','3','4','>4','5','6','7','8','9','>9') NOT NULL,
  `adac_membership` tinyint(1) NOT NULL,
  `safety_training_certificate` tinyint(1) NOT NULL DEFAULT '0',
  `reputation` tinyint(2) NOT NULL,
  `premium_member` tinyint(2) NOT NULL,
  `age_group` enum('16-18','19-24','25-34','35-49','50-65','>65') NOT NULL,
  `car_average_speed` enum('<80','80-100','100-120','120-140','140-160','160-180','180-200','>200') NOT NULL,
  `only_women` tinyint(1) DEFAULT '0',
  `is_nationwide` tinyint(1) NOT NULL DEFAULT '1',
  `booking_active` tinyint(1) NOT NULL DEFAULT '0',
  `price` decimal(5,2) DEFAULT NULL,
  `currency` tinyint(2) NOT NULL DEFAULT '1',
  `train` tinyint(1) NOT NULL DEFAULT '0',
  `highlighting_active` tinyint(1) DEFAULT '0',
  `contentpartner_id` int(4) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `departure_lat` double DEFAULT NULL,
  `departure_long` double DEFAULT NULL,
  `departure_label` varchar(255) DEFAULT NULL,
  `destination_lat` double DEFAULT NULL,
  `destination_long` double DEFAULT NULL,
  `destination_label` varchar(255) DEFAULT NULL,
  `destination_geohash` char(10) DEFAULT NULL,
  `departure_geohash` char(10) DEFAULT NULL,
  KEY `hash_id` (`hash_id`),
  KEY `contentpartner_id` (`contentpartner_id`),
  KEY `date_time` (`date`,`time`),
  KEY `is_nationwide` (`is_nationwide`),
  KEY `departure_district_id` (`departure_district_id`),
  KEY `destination_district_id` (`destination_district_id`),
  KEY `destination_id_nationwide` (`destination_id`,`is_nationwide`),
  KEY `departure_id_nationwide` (`departure_id`,`is_nationwide`),
  KEY `departure_lat_index` (`departure_lat`),
  KEY `departure_long_index` (`departure_long`),
  KEY `destination_lat_index` (`destination_lat`),
  KEY `destination_long_index` (`destination_long`),
  KEY `departure_geohash_index` (`departure_geohash`),
  KEY `destination_geohash_index` (`destination_geohash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
